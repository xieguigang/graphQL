.NET assembly files
